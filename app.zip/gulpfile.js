elixir(function(mix) {
    mix.sass('app.scss');
});
